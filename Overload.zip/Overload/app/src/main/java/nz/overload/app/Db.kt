package nz.overload.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "overload.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE exercise(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE)")
        db.execSQL("CREATE TABLE workout(id INTEGER PRIMARY KEY AUTOINCREMENT, day INTEGER NOT NULL, created INTEGER NOT NULL)")
        db.execSQL(
            "CREATE TABLE workout_exercise(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "workout_id INTEGER NOT NULL REFERENCES workout(id) ON DELETE CASCADE, " +
                "exercise_id INTEGER NOT NULL REFERENCES exercise(id) ON DELETE CASCADE, " +
                "position INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE workout_set(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "we_id INTEGER NOT NULL REFERENCES workout_exercise(id) ON DELETE CASCADE, " +
                "position INTEGER NOT NULL, weight REAL NOT NULL, reps INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_workout_day ON workout(day)")
        db.execSQL("CREATE INDEX idx_we_workout ON workout_exercise(workout_id)")
        db.execSQL("CREATE INDEX idx_we_exercise ON workout_exercise(exercise_id)")
        db.execSQL("CREATE INDEX idx_set_we ON workout_set(we_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------------------------------------------------------------- exercises

    fun findExercise(name: String): Long? =
        readableDatabase.rawQuery("SELECT id FROM exercise WHERE name = ?", arrayOf(Names.clean(name))).use {
            if (it.moveToFirst()) it.getLong(0) else null
        }

    private fun getOrCreate(db: SQLiteDatabase, name: String): Long {
        val n = Names.clean(name)
        db.rawQuery("SELECT id FROM exercise WHERE name = ?", arrayOf(n)).use {
            if (it.moveToFirst()) return it.getLong(0)
        }
        return db.insertOrThrow("exercise", null, ContentValues().apply { put("name", n) })
    }

    fun exerciseName(id: Long): String? =
        readableDatabase.rawQuery("SELECT name FROM exercise WHERE id = ?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    /** Logged sessions per exercise id, oldest first. Only sets with reps count. */
    fun sessionsByExercise(only: Long? = null): Map<Long, List<Session>> {
        val sql = StringBuilder(
            "SELECT we.exercise_id, w.id, w.day, s.weight, s.reps FROM workout_set s " +
                "JOIN workout_exercise we ON we.id = s.we_id " +
                "JOIN workout w ON w.id = we.workout_id WHERE s.reps > 0"
        )
        val args = ArrayList<String>()
        if (only != null) {
            sql.append(" AND we.exercise_id = ?")
            args += only.toString()
        }
        sql.append(" ORDER BY w.day, w.id, we.position, s.position")

        class Acc(val workoutId: Long, val day: Long) { val sets = ArrayList<SetEntry>() }
        val acc = LinkedHashMap<Long, ArrayList<Acc>>()
        readableDatabase.rawQuery(sql.toString(), args.toTypedArray()).use { c ->
            while (c.moveToNext()) {
                val ex = c.getLong(0)
                val wid = c.getLong(1)
                val list = acc.getOrPut(ex) { ArrayList() }
                val cur = list.lastOrNull()?.takeIf { it.workoutId == wid } ?: Acc(wid, c.getLong(2)).also { list.add(it) }
                cur.sets.add(SetEntry(c.getDouble(3), c.getInt(4)))
            }
        }
        return acc.mapValues { (_, l) -> l.map { Session(it.workoutId, it.day, it.sets) } }
    }

    fun exercises(): List<ExerciseInfo> {
        val sessions = sessionsByExercise()
        val out = ArrayList<ExerciseInfo>()
        readableDatabase.rawQuery("SELECT id, name FROM exercise", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += ExerciseInfo(id, c.getString(1), sessions[id] ?: emptyList())
            }
        }
        return out
    }

    fun exercise(id: Long): ExerciseInfo? {
        val name = exerciseName(id) ?: return null
        return ExerciseInfo(id, name, sessionsByExercise(id)[id] ?: emptyList())
    }

    /** The most recent session of this exercise that came before the given workout. */
    fun lastSessionBefore(name: String, day: Long, workoutId: Long): Session? {
        val id = findExercise(name) ?: return null
        val list = sessionsByExercise(id)[id] ?: return null
        return list.lastOrNull { s ->
            s.workoutId != workoutId &&
                (s.day < day || (s.day == day && (workoutId == 0L || s.workoutId < workoutId)))
        }
    }

    /** Returns the id the exercise ends up with (it changes if merged into an existing name). */
    fun renameExercise(id: Long, newName: String): Long {
        val n = Names.clean(newName)
        if (n.isEmpty()) return id
        val db = writableDatabase
        val other = findExercise(n)
        db.beginTransaction()
        try {
            val result = if (other != null && other != id) {
                db.execSQL("UPDATE workout_exercise SET exercise_id = ? WHERE exercise_id = ?", arrayOf<Any>(other, id))
                db.execSQL("DELETE FROM exercise WHERE id = ?", arrayOf<Any>(id))
                other
            } else {
                db.execSQL("UPDATE exercise SET name = ? WHERE id = ?", arrayOf<Any>(n, id))
                id
            }
            db.setTransactionSuccessful()
            return result
        } finally {
            db.endTransaction()
        }
    }

    fun deleteExercise(id: Long) {
        val db = writableDatabase
        db.execSQL("DELETE FROM exercise WHERE id = ?", arrayOf<Any>(id))
        db.execSQL("DELETE FROM workout WHERE id NOT IN (SELECT workout_id FROM workout_exercise)")
    }

    /** Removes exercises no workout uses any more (picked, then removed before logging a set). */
    fun cleanupOrphans() {
        writableDatabase.execSQL("DELETE FROM exercise WHERE id NOT IN (SELECT exercise_id FROM workout_exercise)")
    }

    // ---------------------------------------------------------------- workouts

    fun workoutCount(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM workout", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun workouts(limit: Int): List<WorkoutData> {
        val ids = ArrayList<Long>()
        readableDatabase.rawQuery("SELECT id FROM workout ORDER BY day DESC, id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) ids += c.getLong(0)
        }
        return ids.mapNotNull { loadWorkout(it) }
    }

    fun loadWorkout(id: Long): WorkoutData? {
        val db = readableDatabase
        val day = db.rawQuery("SELECT day FROM workout WHERE id = ?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) it.getLong(0) else null
        } ?: return null
        val items = ArrayList<WorkoutItem>()
        db.rawQuery(
            "SELECT we.id, e.id, e.name FROM workout_exercise we JOIN exercise e ON e.id = we.exercise_id " +
                "WHERE we.workout_id = ? ORDER BY we.position",
            arrayOf(id.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val sets = ArrayList<SetEntry>()
                db.rawQuery(
                    "SELECT weight, reps FROM workout_set WHERE we_id = ? ORDER BY position",
                    arrayOf(c.getLong(0).toString())
                ).use { s ->
                    while (s.moveToNext()) sets += SetEntry(s.getDouble(0), s.getInt(1))
                }
                items += WorkoutItem(c.getString(2), c.getLong(1), sets)
            }
        }
        return WorkoutData(id, day, items)
    }

    /** Creates (id == 0) or replaces a workout. Returns its id. */
    fun saveWorkout(id: Long, day: Long, items: List<Pair<String, List<SetEntry>>>): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var wid = id
            if (wid != 0L) {
                val n = db.update("workout", ContentValues().apply { put("day", day) }, "id = ?", arrayOf(wid.toString()))
                if (n == 0) {
                    db.insertOrThrow("workout", null, ContentValues().apply {
                        put("id", wid); put("day", day); put("created", System.currentTimeMillis())
                    })
                }
            } else {
                wid = db.insertOrThrow("workout", null, ContentValues().apply {
                    put("day", day); put("created", System.currentTimeMillis())
                })
            }
            db.delete("workout_exercise", "workout_id = ?", arrayOf(wid.toString()))
            items.forEachIndexed { i, (name, sets) ->
                val exId = getOrCreate(db, name)
                val weId = db.insertOrThrow("workout_exercise", null, ContentValues().apply {
                    put("workout_id", wid); put("exercise_id", exId); put("position", i)
                })
                sets.forEachIndexed { j, s ->
                    db.insertOrThrow("workout_set", null, ContentValues().apply {
                        put("we_id", weId); put("position", j); put("weight", s.weight); put("reps", s.reps)
                    })
                }
            }
            db.setTransactionSuccessful()
            return wid
        } finally {
            db.endTransaction()
        }
    }

    fun deleteWorkout(id: Long) {
        writableDatabase.delete("workout", "id = ?", arrayOf(id.toString()))
    }

    /** Days (epoch day) from [fromDay] on that have at least one logged set. */
    fun trainedDays(fromDay: Long): Set<Long> {
        val out = HashSet<Long>()
        readableDatabase.rawQuery(
            "SELECT DISTINCT w.day FROM workout w JOIN workout_exercise we ON we.workout_id = w.id " +
                "JOIN workout_set s ON s.we_id = we.id WHERE w.day >= ? AND s.reps > 0",
            arrayOf(fromDay.toString())
        ).use { c -> while (c.moveToNext()) out += c.getLong(0) }
        return out
    }

    fun countWorkouts(fromDay: Long, toDay: Long): Int =
        readableDatabase.rawQuery(
            "SELECT COUNT(DISTINCT w.id) FROM workout w JOIN workout_exercise we ON we.workout_id = w.id " +
                "JOIN workout_set s ON s.we_id = we.id WHERE w.day BETWEEN ? AND ? AND s.reps > 0",
            arrayOf(fromDay.toString(), toDay.toString())
        ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
}
