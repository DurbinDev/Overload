package nz.overload.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.max

/** Back chevron or close cross, drawn so it looks the same on every phone. */
class Icon(ctx: Context, private val kind: Kind, tint: Int = Pal.dust) : View(ctx) {
    enum class Kind { BACK, CLOSE }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = ctx.dpf(2.2f)
        color = tint
    }
    private val path = Path()

    init {
        isClickable = true
        isFocusable = true
        background = pressBg(null, ctx.dpf(24))
        contentDescription = if (kind == Kind.BACK) "Back" else "Remove"
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        when (kind) {
            Kind.BACK -> {
                val s = context.dpf(7)
                path.reset()
                path.moveTo(cx + s * 0.5f, cy - s)
                path.lineTo(cx - s * 0.5f, cy)
                path.lineTo(cx + s * 0.5f, cy + s)
                c.drawPath(path, p)
            }
            Kind.CLOSE -> {
                val s = context.dpf(5)
                c.drawLine(cx - s, cy - s, cx + s, cy + s, p)
                c.drawLine(cx + s, cy - s, cx - s, cy + s, p)
            }
        }
    }
}

/** Green up triangle, red down triangle, level bars, or a hollow ring for a first session. */
class TrendMark(ctx: Context, initial: Trend) : View(ctx) {
    var trend: Trend = initial
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = context.dp(13)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        path.reset()
        p.style = Paint.Style.FILL
        when (trend) {
            Trend.UP -> {
                p.color = Pal.green
                path.moveTo(w / 2, h * 0.12f); path.lineTo(w * 0.95f, h * 0.85f); path.lineTo(w * 0.05f, h * 0.85f)
                path.close(); c.drawPath(path, p)
            }
            Trend.DOWN -> {
                p.color = Pal.red
                path.moveTo(w / 2, h * 0.88f); path.lineTo(w * 0.95f, h * 0.15f); path.lineTo(w * 0.05f, h * 0.15f)
                path.close(); c.drawPath(path, p)
            }
            Trend.SAME -> {
                p.color = Pal.dust
                c.drawRect(w * 0.1f, h * 0.28f, w * 0.9f, h * 0.42f, p)
                c.drawRect(w * 0.1f, h * 0.58f, w * 0.9f, h * 0.72f, p)
            }
            Trend.FIRST -> {
                p.color = Pal.faint
                p.style = Paint.Style.STROKE
                p.strokeWidth = context.dpf(1.5f)
                c.drawCircle(w / 2, h / 2, w * 0.3f, p)
            }
        }
    }
}

/** The last few weeks, Monday to Sunday, with training days filled in plate yellow. */
class DaysGrid(ctx: Context, private val trained: Set<Long>, private val today: Long, private val weeks: Int) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Type.condensed
    }
    private val rect = RectF()
    private val gap = ctx.dpf(5)
    private val cellH = ctx.dpf(26)
    private val labelH = ctx.dpf(20)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = labelH + weeks * cellH + (weeks - 1) * gap
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h.toInt() + 1)
    }

    override fun onDraw(c: Canvas) {
        val cw = (width - 6 * gap) / 7f
        val todayDate = LocalDate.ofEpochDay(today)
        val monday = todayDate.minusDays((todayDate.dayOfWeek.value - 1).toLong())
        val start = monday.minusWeeks((weeks - 1).toLong()).toEpochDay()
        val radius = context.dpf(7)

        txt.textSize = context.sp(12)
        txt.color = Pal.faint
        val names = arrayOf("M", "T", "W", "T", "F", "S", "S")
        for (i in 0 until 7) c.drawText(names[i], i * (cw + gap) + cw / 2, labelH - context.dpf(7), txt)

        for (wk in 0 until weeks) for (d in 0 until 7) {
            val day = start + wk * 7 + d
            val l = d * (cw + gap)
            val t = labelH + wk * (cellH + gap)
            rect.set(l, t, l + cw, t + cellH)
            val isTrained = day in trained
            val future = day > today
            when {
                isTrained -> { fill.color = Pal.yellow; c.drawRoundRect(rect, radius, radius, fill) }
                future -> {
                    stroke.color = Pal.rule; stroke.strokeWidth = context.dpf(1)
                    rect.inset(context.dpf(0.5f), context.dpf(0.5f))
                    c.drawRoundRect(rect, radius, radius, stroke)
                }
                else -> { fill.color = Pal.well; c.drawRoundRect(rect, radius, radius, fill) }
            }
            if (day == today) {
                stroke.color = Pal.chalk; stroke.strokeWidth = context.dpf(2)
                rect.set(l, t, l + cw, t + cellH)
                rect.inset(context.dpf(1), context.dpf(1))
                c.drawRoundRect(rect, radius, radius, stroke)
            }
            txt.textSize = context.sp(12)
            txt.color = when {
                isTrained -> Pal.floor
                future -> Pal.rule
                else -> Pal.faint
            }
            val dom = LocalDate.ofEpochDay(day).dayOfMonth.toString()
            c.drawText(dom, l + cw / 2, t + cellH / 2 - (txt.descent() + txt.ascent()) / 2, txt)
        }
    }
}

/** Simple line chart of one number per session, oldest on the left. */
class LineChart(ctx: Context) : View(ctx) {
    var values: List<Double> = emptyList()
        set(v) { field = v; invalidate() }
    var startLabel = ""
    var endLabel = ""
    var format: (Double) -> String = { Fmt.w(it) }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dpf(2.5f)
        color = Pal.yellow
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val area = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.rule; strokeWidth = ctx.dpf(1) }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.faint; textSize = ctx.sp(11) }
    private val path = Path()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), context.dp(190))
    }

    override fun onDraw(c: Canvas) {
        if (values.isEmpty()) return
        val left = context.dpf(48)
        val right = width - context.dpf(10)
        val top = context.dpf(10)
        val bottom = height - context.dpf(26)

        val minV = values.min()
        val maxV = values.max()
        var lo: Double
        var hi: Double
        if (maxV - minV < 1e-9) {
            val pad = if (abs(maxV) < 1e-9) 1.0 else abs(maxV) * 0.1
            lo = minV - pad; hi = maxV + pad
        } else {
            val pad = (maxV - minV) * 0.15
            lo = minV - pad; hi = maxV + pad
        }
        if (minV >= 0) lo = max(lo, 0.0)

        fun y(v: Double): Float = (bottom - (v - lo) / (hi - lo) * (bottom - top)).toFloat()
        fun x(i: Int): Float =
            if (values.size == 1) (left + right) / 2f else left + i * (right - left) / (values.size - 1)

        txt.textAlign = Paint.Align.RIGHT
        for (k in 0..2) {
            val v = lo + (hi - lo) * k / 2.0
            val yy = y(v)
            c.drawLine(left, yy, right, yy, grid)
            c.drawText(format(v), left - context.dpf(8), yy + context.dpf(4), txt)
        }

        if (values.size > 1) {
            path.reset()
            path.moveTo(x(0), bottom)
            values.forEachIndexed { i, v -> path.lineTo(x(i), y(v)) }
            path.lineTo(x(values.lastIndex), bottom)
            path.close()
            area.shader = LinearGradient(0f, top, 0f, bottom, 0x50F2C230, 0x00F2C230, Shader.TileMode.CLAMP)
            c.drawPath(path, area)

            path.reset()
            values.forEachIndexed { i, v -> if (i == 0) path.moveTo(x(i), y(v)) else path.lineTo(x(i), y(v)) }
            c.drawPath(path, line)
        }

        values.forEachIndexed { i, v ->
            val last = i == values.lastIndex
            if (values.size <= 40 || last) {
                dot.color = Pal.yellow
                c.drawCircle(x(i), y(v), context.dpf(if (last) 5.5f else 3f), dot)
                if (last) {
                    dot.color = Pal.floor
                    c.drawCircle(x(i), y(v), context.dpf(2.2f), dot)
                }
            }
        }

        val by = height - context.dpf(6)
        if (values.size == 1) {
            txt.textAlign = Paint.Align.CENTER
            c.drawText(endLabel, (left + right) / 2f, by, txt)
        } else {
            txt.textAlign = Paint.Align.LEFT
            c.drawText(startLabel, left, by, txt)
            txt.textAlign = Paint.Align.RIGHT
            c.drawText(endLabel, right, by, txt)
        }
        txt.color = Pal.faint
    }

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }
}
