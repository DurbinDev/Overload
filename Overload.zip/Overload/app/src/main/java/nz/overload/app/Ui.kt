package nz.overload.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Gym-floor palette: rubber-floor slate, chalk white, competition-plate yellow / green / red. */
object Pal {
    val floor = Color.parseColor("#1E2126")
    val plate = Color.parseColor("#2A2E35")
    val well = Color.parseColor("#363B43")
    val rule = Color.parseColor("#30353C")
    val chalk = Color.parseColor("#ECEAE4")
    val dust = Color.parseColor("#A6AAB1")
    val faint = Color.parseColor("#70757E")
    val yellow = Color.parseColor("#F2C230")
    val green = Color.parseColor("#4CB873")
    val red = Color.parseColor("#E5585D")
}

object Type {
    val condensed: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val regular: Typeface = Typeface.DEFAULT
}

const val MATCH = -1
const val WRAP = -2

fun Context.dp(v: Number): Int = Math.round(v.toFloat() * resources.displayMetrics.density)
fun Context.dpf(v: Number): Float = v.toFloat() * resources.displayMetrics.density
fun Context.sp(v: Number): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v.toFloat(), resources.displayMetrics)

fun shape(fill: Int, radius: Float, strokeWidth: Int = 0, strokeColor: Int = 0, dash: Float = 0f): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius
        if (strokeWidth > 0) {
            if (dash > 0f) setStroke(strokeWidth, strokeColor, dash, dash * 0.7f) else setStroke(strokeWidth, strokeColor)
        }
    }

fun pressBg(fill: Drawable?, radius: Float): Drawable =
    RippleDrawable(ColorStateList.valueOf(0x30FFFFFF), fill, shape(Color.WHITE, radius))

fun Context.col(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.row(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.label(s: CharSequence, size: Float = 15f, color: Int = Pal.chalk, face: Typeface = Type.regular): TextView =
    TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = face
    }

fun TextView.oneLine(): TextView = apply {
    maxLines = 1
    ellipsize = TextUtils.TruncateAt.END
}

fun Context.rule(): View = View(this).apply { setBackgroundColor(Pal.rule) }

/** Adds [v] to this LinearLayout with the given size, weight and margins (px). */
fun <V : View> LinearLayout.put(
    v: V, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
): V {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) })
    return v
}

enum class Btn { PRIMARY, OUTLINE, GHOST, DANGER }

fun Context.button(label: String, style: Btn, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    gravity = Gravity.CENTER
    isClickable = true
    isFocusable = true
    val r = dpf(14)
    when (style) {
        Btn.PRIMARY -> {
            textSize = 20f; typeface = Type.condensed; setTextColor(Pal.floor)
            background = pressBg(shape(Pal.chalk, r), r)
        }
        Btn.OUTLINE -> {
            textSize = 16f; typeface = Type.medium; setTextColor(Pal.chalk)
            background = pressBg(shape(Color.TRANSPARENT, r, dp(1.5f), Pal.faint, dpf(6)), r)
        }
        Btn.GHOST -> {
            textSize = 15f; typeface = Type.medium; setTextColor(Pal.yellow)
            background = pressBg(null, r)
            setPadding(dp(12), 0, dp(12), 0)
        }
        Btn.DANGER -> {
            textSize = 15f; typeface = Type.medium; setTextColor(Pal.red)
            background = pressBg(null, r)
            setPadding(dp(12), 0, dp(12), 0)
        }
    }
    setOnClickListener { onClick() }
}

/** Big, easy-to-hit number box for weight / reps. */
fun Context.numField(decimal: Boolean): EditText = EditText(this).apply {
    inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    else InputType.TYPE_CLASS_NUMBER
    imeOptions = EditorInfo.IME_ACTION_NEXT or EditorInfo.IME_FLAG_NO_EXTRACT_UI
    textSize = 22f
    typeface = Type.condensed
    setTextColor(Pal.chalk)
    setHintTextColor(Pal.faint)
    gravity = Gravity.CENTER
    val r = dpf(10)
    background = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), shape(Pal.well, r, dp(2), Pal.yellow))
        addState(intArrayOf(), shape(Pal.well, r))
    }
    setPadding(dp(6), dp(8), dp(6), dp(8))
    setSelectAllOnFocus(true)
}

fun Context.textField(hintText: String): EditText = EditText(this).apply {
    hint = hintText
    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
    imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
    textSize = 17f
    setTextColor(Pal.chalk)
    setHintTextColor(Pal.faint)
    background = shape(Pal.well, dpf(12))
    setPadding(dp(14), dp(11), dp(14), dp(11))
}

fun EditText.onChange(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) = f(s?.toString() ?: "")
    })
}

fun trendColor(t: Trend) = when (t) {
    Trend.UP -> Pal.green
    Trend.DOWN -> Pal.red
    Trend.SAME -> Pal.dust
    Trend.FIRST -> Pal.faint
}

fun trendWord(t: Trend) = when (t) {
    Trend.UP -> "Up"
    Trend.DOWN -> "Down"
    Trend.SAME -> "Level"
    Trend.FIRST -> "New"
}
