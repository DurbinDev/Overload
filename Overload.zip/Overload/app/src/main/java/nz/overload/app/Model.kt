package nz.overload.app

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

/** One logged set. weight 0 means bodyweight. */
data class SetEntry(val weight: Double, val reps: Int)

/** Every set of one exercise inside one workout. */
data class Session(val workoutId: Long, val day: Long, val sets: List<SetEntry>)

data class WorkoutItem(val name: String, val exerciseId: Long, val sets: List<SetEntry>)

data class WorkoutData(val id: Long, val day: Long, val items: List<WorkoutItem>)

data class ExerciseInfo(val id: Long, val name: String, val sessions: List<Session>)

enum class Trend { UP, SAME, DOWN, FIRST }

class Verdict(val trend: Trend, val changes: List<String>)

object Overload {
    private const val EPS = 1e-6

    /** Estimated one-rep max (Epley). */
    fun e1rm(s: SetEntry): Double = when {
        s.reps <= 0 -> 0.0
        s.reps == 1 -> s.weight
        else -> s.weight * (1 + s.reps / 30.0)
    }

    fun isBodyweight(sets: List<SetEntry>) = sets.isNotEmpty() && sets.all { it.weight <= 0.0 }
    fun volume(sets: List<SetEntry>) = sets.sumOf { it.weight * it.reps }
    fun totalReps(sets: List<SetEntry>) = sets.sumOf { it.reps }

    /** Heaviest set; ties go to the one with more reps. */
    fun topSet(sets: List<SetEntry>): SetEntry? =
        sets.maxWithOrNull(compareBy<SetEntry> { it.weight }.thenBy { it.reps })

    fun bestE1rm(sets: List<SetEntry>) = sets.maxOfOrNull { e1rm(it) } ?: 0.0

    /**
     * Progressive overload check against the previous session of the same exercise.
     * Any increase (heavier top set, more reps on the top set, or more total work) counts as progress.
     */
    fun compare(now: List<SetEntry>, prev: List<SetEntry>?): Verdict {
        if (prev.isNullOrEmpty() || now.isEmpty()) return Verdict(Trend.FIRST, emptyList())
        val changes = ArrayList<String>()
        var up = false
        var down = false
        val tNow = topSet(now)!!
        val tPrev = topSet(prev)!!
        val dw = tNow.weight - tPrev.weight
        if (abs(dw) > EPS) {
            changes += "${Fmt.signed(dw)} kg on your top set"
            if (dw > 0) up = true else down = true
        } else if (tNow.reps != tPrev.reps) {
            val dr = tNow.reps - tPrev.reps
            changes += "${Fmt.signedInt(dr)} ${if (abs(dr) == 1) "rep" else "reps"} on your top set"
            if (dr > 0) up = true else down = true
        }
        val bodyweight = isBodyweight(now) && isBodyweight(prev)
        if (bodyweight) {
            val dr = totalReps(now) - totalReps(prev)
            if (dr != 0) {
                changes += "${Fmt.signedInt(dr)} total reps"
                if (dr > 0) up = true else down = true
            }
        } else {
            val dv = volume(now) - volume(prev)
            if (abs(dv) >= 0.5) {
                changes += "${Fmt.signedVol(dv)} kg total volume"
                if (dv > 0) up = true else down = true
            }
        }
        val trend = when {
            up -> Trend.UP
            down -> Trend.DOWN
            else -> Trend.SAME
        }
        return Verdict(trend, changes)
    }

    /** Mid-workout progress against last time's total. */
    fun soFar(now: List<SetEntry>, prev: List<SetEntry>): String =
        if (isBodyweight(prev)) "So far ${totalReps(now)} of last time's ${totalReps(prev)} reps."
        else "So far ${Fmt.vol(volume(now))} of last time's ${Fmt.vol(volume(prev))} kg total volume."

    /** What to beat next time, based on the previous session. */
    fun target(prev: List<SetEntry>): String {
        val top = topSet(prev) ?: return ""
        return if (isBodyweight(prev)) {
            "To progress, beat ${top.reps} reps on your best set or ${totalReps(prev)} reps in total."
        } else {
            "To progress, beat ${Fmt.set(top)} or ${Fmt.vol(volume(prev))} kg total volume."
        }
    }
}

object Names {
    fun clean(s: String) = s.trim().replace(Regex("\\s+"), " ")

    /** "bench press" -> "Bench Press"; anything with capitals is left as typed. */
    fun title(s: String): String {
        val c = clean(s)
        if (c.any { it.isUpperCase() }) return c
        return c.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercaseChar() } }
    }

    fun parseWeight(s: String): Double =
        s.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it >= 0.0 && it < 5000.0 } ?: 0.0

    fun parseReps(s: String): Int = s.trim().toIntOrNull()?.takeIf { it in 1..999 } ?: 0
}

object Fmt {
    private val dayFmt = DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault())
    private val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())
    private val dowFmt = DateTimeFormatter.ofPattern("EEE", Locale.getDefault())

    fun w(d: Double): String = String.format(Locale.US, "%.2f", d).trimEnd('0').trimEnd('.')
    fun vol(d: Double): String = String.format(Locale.US, "%,d", d.roundToLong())
    fun signed(d: Double) = (if (d >= 0) "+" else "\u2212") + w(abs(d))
    fun signedVol(d: Double) = (if (d >= 0) "+" else "\u2212") + vol(abs(d))
    fun signedInt(i: Int) = (if (i >= 0) "+" else "\u2212") + abs(i)

    fun set(s: SetEntry): String =
        if (s.weight <= 0.0) "${s.reps} ${if (s.reps == 1) "rep" else "reps"}" else "${w(s.weight)} \u00D7 ${s.reps}"

    fun sets(list: List<SetEntry>) = list.joinToString(",  ") { set(it) }

    fun day(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(dayFmt)
    fun month(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(monthFmt)
    fun dow(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(dowFmt)

    fun relDay(epochDay: Long, capital: Boolean = true): String {
        val today = LocalDate.now().toEpochDay()
        val s = when (epochDay) {
            today -> "today"
            today - 1 -> "yesterday"
            else -> return day(epochDay)
        }
        return if (capital) s.replaceFirstChar { it.uppercaseChar() } else s
    }

    fun count(n: Int, one: String, many: String) = "$n ${if (n == 1) one else many}"
}

val SUGGESTIONS = listOf(
    "Bench Press", "Incline Bench Press", "Dumbbell Bench Press", "Incline Dumbbell Press",
    "Overhead Press", "Dumbbell Shoulder Press", "Lateral Raise", "Rear Delt Fly", "Cable Fly",
    "Push-ups", "Dips", "Squat", "Front Squat", "Leg Press", "Bulgarian Split Squat", "Lunges",
    "Deadlift", "Romanian Deadlift", "Hip Thrust", "Leg Extension", "Leg Curl", "Calf Raise",
    "Pull-ups", "Chin-ups", "Lat Pulldown", "Seated Cable Row", "Barbell Row", "Dumbbell Row",
    "Face Pull", "Shrugs", "Barbell Curl", "Dumbbell Curl", "Hammer Curl", "Tricep Pushdown",
    "Skull Crushers", "Overhead Tricep Extension", "Hanging Leg Raise", "Cable Crunch"
)
