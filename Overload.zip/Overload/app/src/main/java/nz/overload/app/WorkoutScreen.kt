package nz.overload.app

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDate

class SetDraft(var weight: String, var reps: String, var hintW: String, var hintR: String)

class ItemDraft(var name: String, val sets: MutableList<SetDraft>, var last: Session?) {
    fun valid(): List<SetEntry> = sets.mapNotNull { s ->
        val reps = Names.parseReps(s.reps)
        if (reps > 0) SetEntry(Names.parseWeight(s.weight), reps) else null
    }
}

class WorkoutScreen(act: MainActivity, workoutId: Long = 0L, repeatFrom: Long = 0L) : Screen(act) {
    private var id = 0L
    private var day = LocalDate.now().toEpochDay()
    private val items = ArrayList<ItemDraft>()
    private var deleted = false
    private var savedSig = ""
    private var wroteSomething = false

    private var scroll: ScrollView? = null
    private var savedScroll = 0
    private var focusNewItem = false

    init {
        if (workoutId != 0L) {
            db.loadWorkout(workoutId)?.let { w ->
                id = w.id
                day = w.day
                for (item in w.items) {
                    val last = db.lastSessionBefore(item.name, day, id)
                    val prev = last?.sets ?: emptyList()
                    val sets = item.sets.mapIndexed { i, s ->
                        SetDraft(if (s.weight > 0) Fmt.w(s.weight) else "", s.reps.toString(), hintW(prev, i), hintR(prev, i))
                    }
                    items += ItemDraft(item.name, sets.toMutableList(), last)
                }
            }
        } else if (repeatFrom != 0L) {
            db.loadWorkout(repeatFrom)?.items?.forEach { addExercise(it.name) }
        }
        if (id != 0L) savedSig = signature()
    }

    /** Fingerprint of what would be saved, so unchanged workouts aren't rewritten. */
    private fun signature(): String = "$day|" + items.joinToString(";") { item ->
        item.name + ":" + item.valid().joinToString(",") { "${it.weight}x${it.reps}" }
    }

    private fun hintW(prev: List<SetEntry>, i: Int): String =
        prev.getOrNull(i)?.let { if (it.weight > 0) Fmt.w(it.weight) else "BW" } ?: "kg"

    private fun hintR(prev: List<SetEntry>, i: Int): String =
        prev.getOrNull(i)?.reps?.toString() ?: "reps"

    /** Adds an exercise with one empty row per set you did last time, hinted with last time's numbers. */
    private fun addExercise(name: String) {
        val clean = Names.clean(name)
        val last = db.lastSessionBefore(clean, day, id)
        val prev = last?.sets ?: emptyList()
        val sets = MutableList(maxOf(1, prev.size)) { i -> SetDraft("", "", hintW(prev, i), hintR(prev, i)) }
        items += ItemDraft(clean, sets, last)
    }

    // ------------------------------------------------------------------ saving

    private fun save(final: Boolean) {
        if (deleted) return
        val logged = items.map { it.name to it.valid() }
        val anySets = logged.any { it.second.isNotEmpty() }
        val sig = signature()
        if (final) {
            if (!anySets) {
                if (id != 0L) {
                    db.deleteWorkout(id)
                    act.toast("Empty workout removed")
                }
                id = 0L
                return
            }
            val tidy = logged.all { it.second.isNotEmpty() }
            if (!(id != 0L && sig == savedSig && tidy)) {
                id = db.saveWorkout(id, day, logged.filter { it.second.isNotEmpty() })
                savedSig = sig
                wroteSomething = true
            }
            if (wroteSomething) act.toast("Workout saved")
        } else {
            if (items.isEmpty() || (id != 0L && sig == savedSig)) return
            id = db.saveWorkout(id, day, logged)
            savedSig = sig
            wroteSomething = true
        }
    }

    override fun onPause() = save(false)

    override fun onHide() {
        savedScroll = scroll?.scrollY ?: 0
        save(false)
    }

    override fun onLeave() = save(true)

    // --------------------------------------------------------------------- UI

    override fun build(): View {
        val root = act.col()

        val dateBox = act.col().apply {
            setPadding(dp(8), dp(2), dp(8), dp(4))
            background = pressBg(null, dpf(10))
            isClickable = true
            setOnClickListener { pickDate() }
        }
        dateBox.put(act.label(Fmt.relDay(day).let { if (it == Fmt.day(day)) it else "$it, ${Fmt.day(day)}" }, 22f, Pal.chalk, Type.condensed).oneLine(), WRAP, WRAP)
        dateBox.put(act.label("Change date", 13f, Pal.yellow), WRAP, WRAP)
        val done = act.button("Done", Btn.GHOST) { act.goBack() }
        root.put(topBar(dateBox, done))

        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val body = act.col().apply { setPadding(dp(14), dp(4), dp(14), dp(48)) }
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))

        var newItemField: EditText? = null
        items.forEachIndexed { i, item ->
            val first = exerciseBlock(body, item, i)
            if (i == items.lastIndex) newItemField = first
        }

        if (items.isEmpty()) {
            body.put(act.label("Pick your first exercise to start logging sets.", 15f, Pal.dust).apply {
                gravity = Gravity.CENTER
            }, t = dp(40), b = dp(16))
        }
        body.put(act.button("Add exercise", Btn.OUTLINE) { openPicker() }, MATCH, dp(56), t = dp(if (items.isEmpty()) 0 else 14))

        if (id != 0L || items.isNotEmpty()) {
            val del = act.button("Delete workout", Btn.DANGER) { confirmDelete() }
            val wrap = act.row().apply { gravity = Gravity.CENTER_HORIZONTAL }
            wrap.put(del, WRAP, dp(44))
            body.put(wrap, t = dp(28))
        }

        root.put(sv, MATCH, 0, 1f)
        scroll = sv

        if (focusNewItem && newItemField != null) {
            focusNewItem = false
            act.showKeyboard(newItemField!!)
        } else {
            val y = savedScroll
            if (y > 0) sv.post { sv.scrollTo(0, y) }
        }
        return root
    }

    /** Builds one exercise block. Returns its first weight field. */
    private fun exerciseBlock(body: LinearLayout, item: ItemDraft, index: Int): EditText? {
        val card = act.col().apply {
            background = shape(Pal.plate, dpf(18))
            setPadding(dp(14), dp(8), dp(6), dp(10))
        }

        val head = act.row()
        head.put(act.label(item.name, 20f, Pal.chalk, Type.medium).apply { maxLines = 2 }, 0, WRAP, 1f, t = dp(4))
        head.put(Icon(act, Icon.Kind.CLOSE, Pal.faint).apply { setOnClickListener { removeItem(item) } }, dp(44), dp(44))
        card.put(head)

        val last = item.last
        val lastText = if (last == null) {
            "First time logging this. Today sets your baseline."
        } else {
            "Last session, ${Fmt.relDay(last.day, capital = false)}: ${Fmt.sets(last.sets)}"
        }
        card.put(act.label(lastText, 14f, Pal.dust).apply { setLineSpacing(0f, 1.15f) }, r = dp(10))

        val hdr = act.row()
        hdr.put(act.label("Set", 12f, Pal.faint).apply { gravity = Gravity.CENTER }, dp(34), WRAP)
        hdr.put(act.label("kg", 12f, Pal.faint).apply { gravity = Gravity.CENTER }, 0, WRAP, 1f)
        hdr.put(act.label("Reps", 12f, Pal.faint).apply { gravity = Gravity.CENTER }, 0, WRAP, 1f, l = dp(10))
        hdr.put(View(act), dp(44), 1)
        card.put(hdr, t = dp(12))

        val rows = act.col()
        card.put(rows, t = dp(4))

        val status = act.row().apply { gravity = Gravity.TOP }
        val mark = TrendMark(act, Trend.FIRST)
        val statusText = act.label("", 14f, Pal.dust).apply { setLineSpacing(0f, 1.15f) }
        status.put(mark, WRAP, WRAP, t = dp(3))
        status.put(statusText, 0, WRAP, 1f, l = dp(8), r = dp(8))

        val fields = fillRows(item, rows, mark, statusText)

        val addRow = act.row()
        addRow.put(act.button("Add set", Btn.GHOST) {
            val f = addSet(item, rows, mark, statusText)
            act.showKeyboard(f)
        }, WRAP, dp(40), l = dp(22))
        card.put(addRow, t = dp(4))
        card.put(act.rule(), MATCH, 1, t = dp(4), r = dp(8), b = dp(10))
        card.put(status)

        body.put(card, t = dp(if (index == 0) 4 else 12))
        return fields.firstOrNull()
    }

    /** (Re)builds the set rows of one exercise. Returns the weight fields in order. */
    private fun fillRows(item: ItemDraft, rows: LinearLayout, mark: TrendMark, statusText: TextView): List<EditText> {
        rows.removeAllViews()
        val weightFields = ArrayList<EditText>()
        item.sets.forEachIndexed { j, s ->
            val r = act.row()
            r.put(act.label("${j + 1}", 17f, Pal.faint, Type.condensed).apply { gravity = Gravity.CENTER }, dp(34), WRAP)
            val wf = act.numField(true).apply { setText(s.weight); hint = s.hintW }
            val rf = act.numField(false).apply { setText(s.reps); hint = s.hintR }
            wf.onChange { s.weight = it; updateStatus(item, mark, statusText) }
            rf.onChange { s.reps = it; updateStatus(item, mark, statusText) }
            r.put(wf, 0, WRAP, 1f)
            r.put(rf, 0, WRAP, 1f, l = dp(10))
            r.put(Icon(act, Icon.Kind.CLOSE, Pal.faint).apply {
                contentDescription = "Remove set ${j + 1}"
                setOnClickListener {
                    item.sets.remove(s)
                    act.hideKeyboard()
                    fillRows(item, rows, mark, statusText)
                }
            }, dp(44), dp(44))
            rows.put(r, t = if (j == 0) 0 else dp(8))
            weightFields += wf
        }
        updateStatus(item, mark, statusText)
        return weightFields
    }

    /** Adds a set, carrying the weight over from the set above. Returns the field to type into next. */
    private fun addSet(item: ItemDraft, rows: LinearLayout, mark: TrendMark, statusText: TextView): EditText {
        val above = item.sets.lastOrNull()
        val i = item.sets.size
        val prev = item.last?.sets ?: emptyList()
        val hw = prev.getOrNull(i)?.let { if (it.weight > 0) Fmt.w(it.weight) else "BW" }
            ?: above?.weight?.takeIf { it.isNotBlank() } ?: above?.hintW ?: "kg"
        val hr = prev.getOrNull(i)?.reps?.toString()
            ?: above?.reps?.takeIf { it.isNotBlank() } ?: above?.hintR ?: "reps"
        val carried = above?.weight ?: ""
        item.sets += SetDraft(carried, "", hw, hr)
        fillRows(item, rows, mark, statusText)
        val row = rows.getChildAt(rows.childCount - 1) as LinearLayout
        // children: number, weight, reps, remove
        return (if (carried.isBlank()) row.getChildAt(1) else row.getChildAt(2)) as EditText
    }

    private fun updateStatus(item: ItemDraft, mark: TrendMark, text: TextView) {
        val now = item.valid()
        val prev = item.last?.sets
        when {
            now.isEmpty() && prev == null -> {
                mark.trend = Trend.FIRST
                text.setTextColor(Pal.dust)
                text.text = "Log your sets to set a baseline."
            }
            now.isEmpty() -> {
                mark.trend = Trend.FIRST
                text.setTextColor(Pal.dust)
                text.text = Overload.target(prev!!)
            }
            prev == null -> {
                mark.trend = Trend.FIRST
                text.setTextColor(Pal.dust)
                text.text = if (Overload.isBodyweight(now)) {
                    "Baseline: ${Fmt.count(now.size, "set", "sets")}, ${Overload.totalReps(now)} reps in total."
                } else {
                    "Baseline: ${Fmt.count(now.size, "set", "sets")}, ${Fmt.vol(Overload.volume(now))} kg total volume."
                }
            }
            else -> {
                val v = Overload.compare(now, prev)
                if (v.trend == Trend.DOWN && now.size < prev.size) {
                    // Still working through the sets: show the running total, not a red mark.
                    mark.trend = Trend.FIRST
                    text.setTextColor(Pal.dust)
                    text.text = Overload.soFar(now, prev)
                    return
                }
                mark.trend = v.trend
                when (v.trend) {
                    Trend.UP -> {
                        text.setTextColor(Pal.chalk)
                        text.text = "Ahead of last time: ${v.changes.joinToString(", ")}."
                    }
                    Trend.SAME -> {
                        text.setTextColor(Pal.dust)
                        text.text = "Level with last time. One more rep or a little more weight keeps you progressing."
                    }
                    Trend.DOWN -> {
                        text.setTextColor(Pal.dust)
                        text.text = "Behind last time so far: ${v.changes.joinToString(", ")}."
                    }
                    Trend.FIRST -> text.text = ""
                }
            }
        }
    }

    // ---------------------------------------------------------------- actions

    private fun openPicker() {
        act.push(PickerScreen(act, items.map { it.name.lowercase() }.toSet()) { name ->
            addExercise(name)
            focusNewItem = true
        })
    }

    private fun removeItem(item: ItemDraft) {
        val doIt = {
            savedScroll = scroll?.scrollY ?: 0
            items.remove(item)
            act.render()
        }
        val n = item.valid().size
        if (n == 0) {
            doIt()
            return
        }
        AlertDialog.Builder(act)
            .setTitle("Remove ${item.name}?")
            .setMessage("Its ${Fmt.count(n, "set", "sets")} in this workout will be removed.")
            .setPositiveButton("Remove") { _, _ -> doIt() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickDate() {
        act.hideKeyboard()
        val d = LocalDate.ofEpochDay(day)
        val dlg = DatePickerDialog(act, { _, y, m, dom ->
            day = LocalDate.of(y, m + 1, dom).toEpochDay()
            // "Last session" depends on the date, so refresh it and the hints.
            for (item in items) {
                item.last = db.lastSessionBefore(item.name, day, id)
                val prev = item.last?.sets ?: emptyList()
                item.sets.forEachIndexed { i, s ->
                    s.hintW = hintW(prev, i)
                    s.hintR = hintR(prev, i)
                }
            }
            savedScroll = scroll?.scrollY ?: 0
            act.render()
        }, d.year, d.monthValue - 1, d.dayOfMonth)
        dlg.datePicker.maxDate = System.currentTimeMillis()
        dlg.show()
    }

    private fun confirmDelete() {
        act.hideKeyboard()
        AlertDialog.Builder(act)
            .setTitle("Delete this workout?")
            .setMessage("Every set logged on ${Fmt.day(day)} in this workout will be deleted.")
            .setPositiveButton("Delete") { _, _ ->
                if (id != 0L) db.deleteWorkout(id)
                deleted = true
                act.toast("Workout deleted")
                act.goBack()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
