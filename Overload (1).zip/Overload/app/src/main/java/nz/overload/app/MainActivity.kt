package nz.overload.app

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {
    lateinit var db: Db
    private lateinit var host: FrameLayout
    private val stack = ArrayList<Screen>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        host = FrameLayout(this).apply {
            setBackgroundColor(Pal.floor)
            isFocusableInTouchMode = true
        }
        setContentView(host)
        push(HomeScreen(this))
    }

    fun push(s: Screen) {
        hideKeyboard()
        stack.lastOrNull()?.onHide()
        stack += s
        render()
    }

    fun goBack() {
        val top = stack.lastOrNull() ?: return
        if (top.onBack()) return
        hideKeyboard()
        if (stack.size == 1) {
            finish()
            return
        }
        stack.removeAt(stack.lastIndex)
        top.onLeave()
        render()
    }

    /** Rebuilds the top screen from its current state. */
    fun render() {
        val s = stack.lastOrNull() ?: return
        host.removeAllViews()
        host.addView(s.build(), FrameLayout.LayoutParams(MATCH, MATCH))
        host.requestFocus() // keeps the keyboard from popping up on its own
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goBack()
    }

    override fun onPause() {
        super.onPause()
        stack.lastOrNull()?.onPause()
    }

    override fun onDestroy() {
        db.close()
        super.onDestroy()
    }

    fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(host.windowToken, 0)
        currentFocus?.clearFocus()
    }

    fun showKeyboard(v: View) {
        v.postDelayed({
            v.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(v, 0)
        }, 120)
    }

    fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

abstract class Screen(val act: MainActivity) {
    val db: Db get() = act.db
    fun dp(v: Number) = act.dp(v)
    fun dpf(v: Number) = act.dpf(v)

    abstract fun build(): View

    /** Another screen is about to be shown on top of this one. */
    open fun onHide() {}

    /** The app is going to the background. */
    open fun onPause() {}

    /** This screen has been closed. */
    open fun onLeave() {}

    /** Return true to swallow the back press. */
    open fun onBack(): Boolean = false

    protected fun topBar(center: View, right: View? = null): LinearLayout {
        val bar = act.row().apply { setPadding(dp(4), dp(8), dp(10), dp(8)) }
        val back = Icon(act, Icon.Kind.BACK, Pal.chalk).apply { setOnClickListener { act.goBack() } }
        bar.put(back, dp(48), dp(48))
        bar.put(center, 0, WRAP, 1f, l = dp(4))
        if (right != null) bar.put(right, WRAP, WRAP, l = dp(8))
        return bar
    }
}
