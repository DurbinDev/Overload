package nz.overload.app

import android.app.AlertDialog
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.roundToInt

class ExerciseScreen(act: MainActivity, private var exId: Long) : Screen(act) {
    private var metric = 0
    private var scroll: ScrollView? = null
    private var savedScroll = 0

    override fun onHide() {
        savedScroll = scroll?.scrollY ?: 0
    }

    override fun build(): View {
        val root = act.col()
        val info = db.exercise(exId)
        root.put(topBar(act.label(info?.name ?: "Exercise", 24f, Pal.chalk, Type.condensed).oneLine()))

        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val body = act.col().apply { setPadding(dp(16), dp(4), dp(16), dp(48)) }
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.put(sv, MATCH, 0, 1f)
        scroll = sv

        if (info == null || info.sessions.isEmpty()) {
            body.put(act.label("No sets logged for this exercise yet.", 15f, Pal.dust), t = dp(16))
            if (info != null) addActions(body, info)
            return root
        }

        val s = info.sessions
        val bodyweight = s.all { Overload.isBodyweight(it.sets) }

        val ups = (1 until s.size).count { Overload.compare(s[it].sets, s[it - 1].sets).trend == Trend.UP }
        val summary = if (s.size == 1) {
            "One session so far. Log it again and you'll see whether you beat it."
        } else {
            "Beat the session before in $ups of ${s.size - 1} ${if (s.size - 1 == 1) "session" else "sessions"}."
        }
        body.put(act.label(summary, 15f, Pal.dust).apply { setLineSpacing(0f, 1.2f) }, t = dp(2))

        // Bests
        val allSets = s.flatMap { it.sets }
        val bests = act.row().apply { gravity = Gravity.TOP }
        if (bodyweight) {
            bests.put(stat(Fmt.set(Overload.topSet(allSets)!!), "Best set"), 0, WRAP, 1f)
            bests.put(stat(s.maxOf { Overload.totalReps(it.sets) }.toString(), "Most reps in a session"), 0, WRAP, 1f, l = dp(10))
        } else {
            bests.put(stat(Fmt.set(Overload.topSet(allSets)!!), "Heaviest set"), 0, WRAP, 1f)
            bests.put(stat("${Overload.bestE1rm(allSets).roundToInt()} kg", "Best est. 1-rep max"), 0, WRAP, 1f, l = dp(10))
        }
        bests.put(stat(s.size.toString(), "Sessions"), 0, WRAP, 0.7f, l = dp(10))
        body.put(bests, t = dp(16))

        // Chart with metric switch
        val metrics = if (bodyweight) listOf("Best set reps", "Total reps") else listOf("Top set", "Est. 1RM", "Volume")
        if (metric >= metrics.size) metric = 0
        val chips = act.row()
        metrics.forEachIndexed { i, name ->
            val sel = i == metric
            chips.put(act.chip(name, sel) {
                if (metric != i) {
                    metric = i
                    savedScroll = scroll?.scrollY ?: 0
                    act.render()
                }
            }, WRAP, WRAP, r = dp(8))
        }
        body.put(chips, t = dp(22))

        val chart = LineChart(act).apply {
            startLabel = Fmt.day(s.first().day)
            endLabel = Fmt.day(s.last().day)
            if (bodyweight) {
                format = { it.roundToInt().toString() }
                values = s.map { if (metric == 0) (Overload.topSet(it.sets)?.reps ?: 0).toDouble() else Overload.totalReps(it.sets).toDouble() }
            } else {
                val volFmt: (Double) -> String = { Fmt.vol(it) }
                val kgFmt: (Double) -> String = { Fmt.w(Math.round(it * 2) / 2.0) }
                format = if (metric == 2) volFmt else kgFmt
                values = s.map {
                    when (metric) {
                        0 -> Overload.topSet(it.sets)?.weight ?: 0.0
                        1 -> Overload.bestE1rm(it.sets)
                        else -> Overload.volume(it.sets)
                    }
                }
            }
        }
        body.put(chart, t = dp(12))
        val unit = when {
            bodyweight -> "reps"
            metric == 0 -> "kg, heaviest set each session"
            metric == 1 -> "kg, estimated from your best set each session"
            else -> "kg, weight \u00D7 reps added up each session"
        }
        body.put(act.label(unit.replaceFirstChar { it.uppercaseChar() }, 12f, Pal.faint), t = dp(2))

        // Every session, newest first
        body.put(act.label("Sessions", 14f, Pal.dust, Type.medium), t = dp(26), b = dp(4))
        for (i in s.indices.reversed()) {
            if (i != s.lastIndex) body.put(act.rule(), MATCH, 1)
            body.put(sessionRow(s[i], if (i > 0) s[i - 1] else null))
        }

        addActions(body, info)

        val y = savedScroll
        if (y > 0) sv.post { sv.scrollTo(0, y) }
        return root
    }

    private fun stat(value: String, name: String): View = act.statBox(value, name)

    private fun sessionRow(sess: Session, before: Session?): View {
        val trend = if (before == null) Trend.FIRST else Overload.compare(sess.sets, before.sets).trend
        val row = act.row().apply {
            gravity = Gravity.TOP
            setPadding(dp(4), dp(12), dp(4), dp(12))
            background = pressBg(null, dpf(10))
            isClickable = true
            setOnClickListener { act.push(WorkoutScreen(act, workoutId = sess.workoutId)) }
        }
        val c = act.col()
        c.put(act.label(Fmt.relDay(sess.day), 16f, Pal.chalk, Type.medium))
        c.put(act.label(Fmt.sets(sess.sets), 14f, Pal.dust).apply { setLineSpacing(0f, 1.15f) }, t = dp(3))
        row.put(c, 0, WRAP, 1f)

        val right = act.col().apply { gravity = Gravity.END }
        val tr = act.row()
        tr.put(TrendMark(act, trend), WRAP, WRAP)
        tr.put(act.label(trendWord(trend), 14f, trendColor(trend), Type.medium), WRAP, WRAP, l = dp(6))
        right.put(tr, WRAP, WRAP)
        val load = if (Overload.isBodyweight(sess.sets)) "${Overload.totalReps(sess.sets)} reps"
        else "${Fmt.vol(Overload.volume(sess.sets))} kg"
        right.put(act.label(load, 13f, Pal.faint), WRAP, WRAP, t = dp(3))
        row.put(right, WRAP, WRAP, l = dp(12))
        return row
    }

    private fun addActions(body: LinearLayout, info: ExerciseInfo) {
        val actions = act.row().apply { gravity = Gravity.CENTER_HORIZONTAL }
        actions.put(act.button("Rename", Btn.GHOST) { rename(info) }, WRAP, dp(44))
        actions.put(act.button("Delete exercise", Btn.DANGER) { confirmDelete(info) }, WRAP, dp(44), l = dp(12))
        body.put(actions, t = dp(28))
    }

    private fun rename(info: ExerciseInfo) {
        val input = act.textField("Exercise name").apply {
            setText(info.name)
            setSelection(text.length)
        }
        val frame = FrameLayout(act).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(act)
            .setTitle("Rename exercise")
            .setMessage("If the new name matches another exercise, their history is combined.")
            .setView(frame)
            .setPositiveButton("Rename") { _, _ ->
                val n = input.text.toString()
                if (n.isNotBlank()) {
                    exId = db.renameExercise(exId, n)
                    act.render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
        act.showKeyboard(input)
    }

    private fun confirmDelete(info: ExerciseInfo) {
        AlertDialog.Builder(act)
            .setTitle("Delete ${info.name}?")
            .setMessage("This deletes every set of ${info.name} you've logged. Workouts left with no exercises are deleted too.")
            .setPositiveButton("Delete") { _, _ ->
                db.deleteExercise(exId)
                act.toast("${info.name} deleted")
                act.goBack()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
