package nz.overload.app

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.time.LocalDate

/** The Weight tab on the home screen. */
class WeightTab(private val home: HomeScreen) {
    private val act get() = home.act
    private val db get() = act.db

    /** A date picked with "Change date"; otherwise weigh-ins go on today. */
    private var pickedDay: Long? = null
    private var range = 0 // 0 month, 1 three months, 2 year, 3 all
    private var showAll = false

    private fun dp(v: Number) = act.dp(v)
    private fun dpf(v: Number) = act.dpf(v)

    fun build(body: LinearLayout) {
        val list = db.weighIns()
        val today = LocalDate.now().toEpochDay()
        val day = (pickedDay ?: today).coerceAtMost(today)
        val existing = list.firstOrNull { it.day == day }
        val before = list.lastOrNull { it.day < day }

        // ---- Entry
        val panel = act.col().apply {
            background = shape(Pal.plate, dpf(18))
            setPadding(dp(16), dp(12), dp(10), dp(16))
        }
        val top = act.row()
        val dateCol = act.col()
        dateCol.put(act.label("Weigh-in", 13f, Pal.dust), WRAP, WRAP)
        val rel = Fmt.relDay(day)
        dateCol.put(act.label(if (rel == Fmt.day(day)) rel else "$rel, ${Fmt.day(day)}", 18f, Pal.chalk, Type.medium).oneLine(), WRAP, WRAP)
        top.put(dateCol, 0, WRAP, 1f)
        top.put(act.button("Change date", Btn.GHOST) { pickDate(day) }, WRAP, dp(40))
        panel.put(top)

        val entry = act.row()
        val field = act.numField(true).apply {
            textSize = 30f
            imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            hint = (before ?: list.lastOrNull())?.let { Fmt.w(it.kg) } ?: "0.0"
            if (existing != null) setText(Fmt.w(existing.kg))
        }
        val updating = existing != null
        entry.put(field, 0, WRAP, 1f)
        entry.put(act.label("kg", 18f, Pal.dust), WRAP, WRAP, l = dp(10))
        entry.put(act.button(if (updating) "Update" else "Save", Btn.PRIMARY) {
            save(day, field.text.toString(), updating)
        }, dp(104), dp(56), l = dp(12), r = dp(6))
        field.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_DONE) {
                save(day, field.text.toString(), updating)
                true
            } else false
        }
        panel.put(entry, t = dp(10))

        val note = when {
            existing != null && before != null ->
                "${Fmt.signedKg1(existing.kg - before.kg)} kg since ${Fmt.relDay(before.day, capital = false)}."
            existing != null -> "Saved. Keep weighing in each day and your trend builds up below."
            before != null -> "Last weigh-in: ${Fmt.w(before.kg)} kg, ${Fmt.relDay(before.day, capital = false)}."
            else -> "For the most consistent numbers, weigh yourself at the same time each day, ideally first thing in the morning."
        }
        panel.put(act.label(note, 14f, Pal.dust).apply { setLineSpacing(0f, 1.2f) }, t = dp(10), r = dp(6))
        body.put(panel)

        if (list.isEmpty()) {
            body.put(act.label(
                "Your weigh-ins and a graph of how your weight is tracking will show up here.",
                15f, Pal.dust
            ).apply { setLineSpacing(0f, 1.25f) }, t = dp(24))
            return
        }

        // ---- Summary
        val avg = WeightStats.avg7(list, list.last().day)!!
        val week = WeightStats.change(list, 7)
        val month = WeightStats.change(list, 30)
        val stats = act.row().apply { gravity = Gravity.TOP }
        stats.put(act.statBox(Fmt.kg1(avg), "7-day average, kg"), 0, WRAP, 1f)
        stats.put(act.statBox(week?.let { Fmt.signedKg1(it) } ?: "\u2013", "Change over 7 days"), 0, WRAP, 1f, l = dp(10))
        if (month != null) {
            stats.put(act.statBox(Fmt.signedKg1(month), "Change over 30 days"), 0, WRAP, 1f, l = dp(10))
        } else {
            stats.put(act.statBox(WeightStats.sinceStart(list)?.let { Fmt.signedKg1(it) } ?: "\u2013", "Change since you started"), 0, WRAP, 1f, l = dp(10))
        }
        body.put(stats, t = dp(14))

        // ---- Chart
        val chips = act.row()
        listOf("Month", "3 months", "Year", "All").forEachIndexed { i, name ->
            chips.put(act.chip(name, i == range) {
                if (range != i) {
                    range = i
                    home.rerender()
                }
            }, WRAP, WRAP, r = dp(8))
        }
        body.put(chips, t = dp(22))

        val first = list.first().day
        val end = maxOf(today, list.last().day)
        val from = when (range) {
            0 -> end - 30
            1 -> end - 91
            2 -> end - 365
            else -> first
        }.coerceAtLeast(first)
        body.put(WeightChart(act).apply {
            points = list
            trend = WeightStats.trend(list)
            fromDay = from
            toDay = end
        }, t = dp(12))
        body.put(act.label(
            "Dots are your daily weigh-ins. The white line is your 7-day average, which smooths out day-to-day swings from water and food.",
            12f, Pal.faint
        ).apply { setLineSpacing(0f, 1.2f) }, t = dp(4))

        // ---- History
        body.put(act.label("Weigh-ins", 14f, Pal.dust, Type.medium), t = dp(24), b = dp(4))
        val count = if (showAll) list.size else minOf(30, list.size)
        for (i in 0 until count) {
            val idx = list.size - 1 - i
            if (i > 0) body.put(act.rule(), MATCH, 1)
            body.put(weighInRow(list[idx], list.getOrNull(idx - 1)))
        }
        if (!showAll && list.size > 30) {
            body.put(act.button("Show all ${list.size} weigh-ins", Btn.GHOST) {
                showAll = true
                home.rerender()
            }, MATCH, dp(48), t = dp(8))
        }
    }

    private fun weighInRow(w: WeighIn, prev: WeighIn?): View {
        val row = act.row().apply {
            setPadding(dp(4), dp(12), dp(4), dp(12))
            background = pressBg(null, dpf(10))
            isClickable = true
            setOnClickListener { edit(w) }
        }
        row.put(act.label(Fmt.relDay(w.day), 16f, Pal.chalk, Type.medium), 0, WRAP, 1f)
        if (prev != null) {
            row.put(act.label(Fmt.signedKg1(w.kg - prev.kg), 14f, Pal.dust), WRAP, WRAP, l = dp(8))
        }
        row.put(act.label("${Fmt.w(w.kg)} kg", 20f, Pal.chalk, Type.condensed).apply {
            gravity = Gravity.END
        }, dp(96), WRAP, l = dp(10))
        return row
    }

    private fun save(day: Long, text: String, updating: Boolean) {
        val kg = Names.parseWeight(text)
        if (kg < 20.0 || kg > 400.0) {
            act.toast("Enter your weight in kg, for example 82.4")
            return
        }
        db.setWeight(day, kg)
        act.hideKeyboard()
        act.toast(if (updating) "Weight updated" else "Weight saved")
        home.rerender()
    }

    private fun pickDate(current: Long) {
        act.hideKeyboard()
        val d = LocalDate.ofEpochDay(current)
        val dlg = DatePickerDialog(act, { _, y, m, dom ->
            val picked = LocalDate.of(y, m + 1, dom).toEpochDay()
            pickedDay = if (picked == LocalDate.now().toEpochDay()) null else picked
            home.rerender()
        }, d.year, d.monthValue - 1, d.dayOfMonth)
        dlg.datePicker.maxDate = System.currentTimeMillis()
        dlg.show()
    }

    private fun edit(w: WeighIn) {
        val input = act.numField(true).apply {
            textSize = 26f
            setText(Fmt.w(w.kg))
        }
        val frame = FrameLayout(act).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        AlertDialog.Builder(act)
            .setTitle(Fmt.relDay(w.day).let { if (it == Fmt.day(w.day)) it else "$it, ${Fmt.day(w.day)}" })
            .setView(frame)
            .setPositiveButton("Save") { _, _ ->
                val kg = Names.parseWeight(input.text.toString())
                if (kg < 20.0 || kg > 400.0) {
                    act.toast("Enter your weight in kg, for example 82.4")
                } else {
                    db.setWeight(w.day, kg)
                    home.rerender()
                }
            }
            .setNeutralButton("Delete") { _, _ ->
                db.deleteWeight(w.day)
                act.toast("Weigh-in deleted")
                home.rerender()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
