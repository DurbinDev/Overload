package nz.overload.app

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import java.time.LocalDate

class HomeScreen(act: MainActivity) : Screen(act) {
    private var tab = 0
    private var limit = 40
    private var scroll: ScrollView? = null
    private var savedScroll = 0
    private val weight = WeightTab(this)

    /** Rebuild this screen, keeping the scroll position. */
    fun rerender() {
        savedScroll = scroll?.scrollY ?: 0
        act.render()
    }

    override fun onHide() {
        savedScroll = scroll?.scrollY ?: 0
    }

    override fun build(): View {
        db.cleanupOrphans()
        val root = act.col()

        val head = act.row().apply { setPadding(dp(20), dp(22), dp(20), dp(4)) }
        head.put(act.label("Pain And Gain", 36f, Pal.chalk, Type.condensed).oneLine(), 0, WRAP, 1f)
        root.put(head)

        val tabs = act.row().apply { setPadding(dp(12), 0, dp(12), 0) }
        listOf("Log", "Progress", "Weight").forEachIndexed { i, name ->
            tabs.put(tabView(name, i == tab) {
                if (tab != i) {
                    tab = i
                    savedScroll = 0
                    act.render()
                }
            }, WRAP, WRAP)
        }
        root.put(tabs)
        root.put(act.rule(), MATCH, 1)

        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val body = act.col().apply { setPadding(dp(16), dp(16), dp(16), dp(40)) }
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        when (tab) {
            0 -> buildLog(body)
            1 -> buildProgress(body)
            else -> weight.build(body)
        }
        root.put(sv, MATCH, 0, 1f)
        scroll = sv
        val y = savedScroll
        if (y > 0) sv.post { sv.scrollTo(0, y) }
        return root
    }

    private fun tabView(name: String, selected: Boolean, onClick: () -> Unit): View {
        val c = act.col().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(10), dp(8), 0)
            isClickable = true
            setOnClickListener { onClick() }
        }
        c.put(act.label(name, 17f, if (selected) Pal.chalk else Pal.faint, Type.medium), WRAP, WRAP)
        c.put(View(act).apply {
            background = shape(if (selected) Pal.accent else Color.TRANSPARENT, dpf(2))
        }, MATCH, dp(3), t = dp(9))
        return c
    }

    // ------------------------------------------------------------------ Log tab

    private fun buildLog(body: LinearLayout) {
        val todayDate = LocalDate.now()
        val today = todayDate.toEpochDay()
        val monday = today - (todayDate.dayOfWeek.value - 1)
        val weeks = 5
        val trained = db.trainedDays(monday - (weeks - 1) * 7L)
        val thisWeek = db.countWorkouts(monday, today)

        val panel = act.col().apply {
            background = shape(Pal.plate, dpf(18))
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        val weekText = when (thisWeek) {
            0 -> "No workouts yet this week"
            1 -> "1 workout this week"
            else -> "$thisWeek workouts this week"
        }
        panel.put(act.label(weekText, 16f, Pal.chalk, Type.medium))
        panel.put(DaysGrid(act, trained, today, weeks), t = dp(12))
        body.put(panel)

        body.put(act.button("Start workout", Btn.PRIMARY) { act.push(WorkoutScreen(act)) }, MATCH, dp(58), t = dp(14))

        val list = db.workouts(limit)
        if (list.isEmpty()) {
            body.put(act.label(
                "Your workouts will show up here. Tap Start workout, pick an exercise, then log the weight and reps for each set.",
                15f, Pal.dust
            ).apply { setLineSpacing(0f, 1.25f) }, t = dp(24))
            return
        }

        val sessions = db.sessionsByExercise()
        var month = ""
        list.forEachIndexed { idx, w ->
            val m = Fmt.month(w.day)
            if (m != month) {
                month = m
                body.put(act.label(m, 14f, Pal.dust, Type.medium), t = dp(if (idx == 0) 26 else 22), b = dp(2))
            } else {
                body.put(act.rule(), MATCH, 1, l = dp(60))
            }
            body.put(workoutRow(w, sessions, today))
        }
        if (db.workoutCount() > limit) {
            body.put(act.button("Show older workouts", Btn.GHOST) {
                savedScroll = scroll?.scrollY ?: 0
                limit += 40
                act.render()
            }, MATCH, dp(48), t = dp(8))
        }
    }

    private fun workoutRow(w: WorkoutData, sessions: Map<Long, List<Session>>, today: Long): View {
        val row = act.row().apply {
            gravity = Gravity.TOP
            setPadding(0, dp(12), 0, dp(6))
            background = pressBg(null, dpf(12))
            isClickable = true
            setOnClickListener { act.push(WorkoutScreen(act, workoutId = w.id)) }
        }

        val date = act.col().apply { gravity = Gravity.CENTER_HORIZONTAL }
        val d = LocalDate.ofEpochDay(w.day)
        date.put(act.label(d.dayOfMonth.toString(), 30f, if (w.day == today) Pal.accent else Pal.chalk, Type.condensed).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        })
        date.put(act.label(Fmt.dow(w.day), 13f, Pal.dust).apply { gravity = Gravity.CENTER }, t = dp(2))
        row.put(date, dp(52), WRAP)

        val content = act.col()
        val done = w.items.filter { it.sets.isNotEmpty() }
        if (done.isEmpty()) content.put(act.label("No sets logged yet", 15f, Pal.faint), t = dp(4))
        for (item in done) {
            val line = act.row()
            line.put(act.label(item.name, 15f, Pal.chalk).oneLine(), 0, WRAP, 1f)
            line.put(act.label(Fmt.count(item.sets.size, "set", "sets"), 13f, Pal.dust), WRAP, WRAP, l = dp(8))
            val top = Overload.topSet(item.sets)!!
            line.put(act.label(Fmt.set(top), 17f, Pal.chalk, Type.condensed), WRAP, WRAP, l = dp(10))
            line.put(TrendMark(act, trendFor(item.exerciseId, w.id, sessions)), WRAP, WRAP, l = dp(8))
            content.put(line, t = dp(if (content.childCount == 0) 3 else 7))
        }
        if (done.isNotEmpty()) {
            val actions = act.row().apply { gravity = Gravity.END }
            actions.put(act.button("Repeat", Btn.GHOST) { act.push(WorkoutScreen(act, repeatFrom = w.id)) }, WRAP, dp(38))
            content.put(actions, t = dp(2))
        } else {
            content.put(View(act), MATCH, dp(10))
        }
        row.put(content, 0, WRAP, 1f, l = dp(8))
        return row
    }

    private fun trendFor(exerciseId: Long, workoutId: Long, sessions: Map<Long, List<Session>>): Trend {
        val list = sessions[exerciseId] ?: return Trend.FIRST
        val i = list.indexOfFirst { it.workoutId == workoutId }
        if (i <= 0) return Trend.FIRST
        return Overload.compare(list[i].sets, list[i - 1].sets).trend
    }

    // ------------------------------------------------------------- Progress tab

    private fun buildProgress(body: LinearLayout) {
        val list = db.exercises().filter { it.sessions.isNotEmpty() }
            .sortedWith(compareByDescending<ExerciseInfo> { it.sessions.last().day }.thenByDescending { it.sessions.last().workoutId })
        if (list.isEmpty()) {
            body.put(act.label(
                "Exercises you log show up here, along with whether you beat the session before.",
                15f, Pal.dust
            ).apply { setLineSpacing(0f, 1.25f) }, t = dp(8))
            return
        }
        val trends = list.map { ex ->
            val s = ex.sessions
            if (s.size < 2) Trend.FIRST else Overload.compare(s.last().sets, s[s.size - 2].sets).trend
        }
        val compared = trends.count { it != Trend.FIRST }
        val ups = trends.count { it == Trend.UP }
        val summary = if (compared == 0) {
            "Log an exercise a second time to see whether you're progressing on it."
        } else {
            "Progressing on $ups of $compared ${if (compared == 1) "exercise" else "exercises"}, comparing each one's latest session with the one before it."
        }
        body.put(act.label(summary, 15f, Pal.dust).apply { setLineSpacing(0f, 1.25f) }, b = dp(8))

        list.forEachIndexed { i, ex ->
            if (i > 0) body.put(act.rule(), MATCH, 1)
            body.put(exerciseRow(ex, trends[i]))
        }
    }

    private fun exerciseRow(ex: ExerciseInfo, trend: Trend): View {
        val last = ex.sessions.last()
        val row = act.row().apply {
            setPadding(dp(4), dp(14), dp(4), dp(14))
            background = pressBg(null, dpf(12))
            isClickable = true
            setOnClickListener { act.push(ExerciseScreen(act, ex.id)) }
        }
        val c = act.col()
        c.put(act.label(ex.name, 17f, Pal.chalk, Type.medium).oneLine())
        c.put(act.label("${Fmt.relDay(last.day)}, top set ${Fmt.set(Overload.topSet(last.sets)!!)}", 13f, Pal.dust).oneLine(), t = dp(3))
        row.put(c, 0, WRAP, 1f)

        val right = act.col().apply { gravity = Gravity.END }
        val tr = act.row()
        tr.put(TrendMark(act, trend), WRAP, WRAP)
        tr.put(act.label(trendWord(trend), 15f, trendColor(trend), Type.medium), WRAP, WRAP, l = dp(6))
        right.put(tr, WRAP, WRAP)
        right.put(act.label(Fmt.count(ex.sessions.size, "session", "sessions"), 12f, Pal.faint), WRAP, WRAP, t = dp(3))
        row.put(right, WRAP, WRAP, l = dp(12))
        return row
    }
}
