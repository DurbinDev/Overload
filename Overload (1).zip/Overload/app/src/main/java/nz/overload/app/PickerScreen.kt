package nz.overload.app

import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class PickerScreen(
    act: MainActivity,
    private val inWorkout: Set<String>,
    private val onPick: (String) -> Unit
) : Screen(act) {
    private var query = ""

    /** Exercises you've used, most recently done first; never-logged ones after, A to Z. */
    private val known: List<ExerciseInfo> by lazy {
        db.exercises().sortedWith(
            compareByDescending<ExerciseInfo> { it.sessions.isNotEmpty() }
                .thenByDescending { it.sessions.lastOrNull()?.day ?: Long.MIN_VALUE }
                .thenBy { it.name.lowercase() }
        )
    }

    override fun build(): View {
        val root = act.col()
        val search = act.textField("Search or type a new exercise").apply {
            setText(query)
            setSelection(text.length)
        }
        root.put(topBar(search))

        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }
        val list = act.col().apply { setPadding(dp(16), dp(4), dp(16), dp(40)) }
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.put(sv, MATCH, 0, 1f)

        fill(list)
        search.onChange {
            query = it
            fill(list)
        }
        search.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_DONE && Names.clean(query).isNotEmpty()) {
                choose(bestMatch(Names.clean(query)))
                true
            } else false
        }
        act.showKeyboard(search)
        return root
    }

    private fun matches(name: String, words: List<String>) = words.all { name.lowercase().contains(it) }

    /** Enter on the keyboard: exact or single match if there is one, otherwise a new exercise. */
    private fun bestMatch(q: String): String {
        known.firstOrNull { it.name.equals(q, ignoreCase = true) }?.let { return it.name }
        SUGGESTIONS.firstOrNull { it.equals(q, ignoreCase = true) }?.let { return it }
        return Names.title(q)
    }

    private fun fill(list: LinearLayout) {
        list.removeAllViews()
        val q = Names.clean(query)
        val words = q.lowercase().split(" ").filter { it.isNotEmpty() }
        val knownNames = known.map { it.name.lowercase() }.toSet()
        val mine = known.filter { matches(it.name, words) }
        val more = SUGGESTIONS.filter { it.lowercase() !in knownNames && matches(it, words) }
        val exact = q.isNotEmpty() &&
            (q.lowercase() in knownNames || SUGGESTIONS.any { it.equals(q, ignoreCase = true) })

        if (q.isNotEmpty() && !exact) {
            val title = Names.title(q)
            list.put(pickRow("Add \u201C$title\u201D", "New exercise", accent = true) { choose(title) }, t = dp(6))
        }
        if (mine.isNotEmpty()) {
            list.put(act.label("Your exercises", 14f, Pal.dust, Type.medium), t = dp(16), b = dp(4))
            mine.forEachIndexed { i, ex ->
                if (i > 0) list.put(act.rule(), MATCH, 1)
                list.put(pickRow(ex.name, subtitle(ex)) { choose(ex.name) })
            }
        }
        if (more.isNotEmpty()) {
            list.put(act.label(if (known.isEmpty()) "Common exercises" else "More exercises", 14f, Pal.dust, Type.medium), t = dp(20), b = dp(4))
            more.forEachIndexed { i, name ->
                if (i > 0) list.put(act.rule(), MATCH, 1)
                list.put(pickRow(name, null) { choose(name) })
            }
        }
        if (q.isNotEmpty() && mine.isEmpty() && more.isEmpty() && exact) {
            list.put(act.label("No matches.", 15f, Pal.faint), t = dp(16))
        }
    }

    private fun subtitle(ex: ExerciseInfo): String? {
        if (ex.name.lowercase() in inWorkout) return "Already in this workout"
        val last = ex.sessions.lastOrNull() ?: return null
        return "${Fmt.relDay(last.day)}, top set ${Fmt.set(Overload.topSet(last.sets)!!)}"
    }

    private fun pickRow(title: String, sub: String?, accent: Boolean = false, onClick: () -> Unit): View {
        val c = act.col().apply {
            setPadding(dp(4), dp(13), dp(4), dp(13))
            background = pressBg(null, dpf(10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        c.put(act.label(title, 17f, if (accent) Pal.accent else Pal.chalk, Type.medium).oneLine())
        if (sub != null) c.put(act.label(sub, 13f, Pal.dust).oneLine(), t = dp(2))
        return c
    }

    private fun choose(name: String) {
        act.hideKeyboard()
        onPick(name)
        act.goBack()
    }
}
